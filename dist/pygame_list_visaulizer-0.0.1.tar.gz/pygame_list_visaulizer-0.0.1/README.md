https://github.com/Jawou/pygame_bubblesort_visualizer is another usage example
<img width="384" height="528" alt="image" src="https://github.com/user-attachments/assets/a0e8c4c7-48f7-4da8-bfa6-e944e01afc33" />
<img width="1041" height="1077" alt="image" src="https://github.com/user-attachments/assets/b6f8375c-b162-4a39-9780-fdad88c21f90" />
