from setuptools import setup, find_packages

setup(
  name='pygame_list_visaulizer',
  versions='0.1',
  packages=find_packages(),
  instal_requires=[
    'pygame-ce'
  ],




)